const express = require('express');
const router = express.Router();

const verificarToken = require('../middlewares/revisarToken');
const RevisarTokenReact = require('../middlewares/revisarTokenReact');

const UsuarioController = require('../controller/usuarios_controller');

router.route('/ingresar')
    .get((req, res) => {res.render('ingresar')});

router.route('/ingresar')
    .post(UsuarioController.inicioSesion);

router.post('/permisos', RevisarTokenReact, UsuarioController.obtenerPermisos);

router.get('/', verificarToken, (req, res) => {console.log("Entrado a página incial...");res.render('index')});

module.exports = router;

import React, { Component } from "react";
import './presentacion.style.css';

class Presentacion extends Component{
    constructor(props){
        super(props);

        this.renderSide = this.renderSide.bind(this);
        this.renderPageContent = this.renderPageContent.bind(this);
        this.renderNavbar = this.renderNavbar.bind(this);
    }

    renderSide(){
        return (
            <nav id="sidebar">
                <div className="sidebar-header">
                    <h3>Bootstrap Sidebar</h3>
                </div>

                <ul className="list-unstyled components">
                    <p>Dummy Heading</p>
                    <li className="active">
                        <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false"
                           className="dropdown-toggle">Home</a>
                        <ul className="collapse list-unstyled" id="homeSubmenu">
                            <li>
                                <a href="#">Home 1</a>
                            </li>
                            <li>
                                <a href="#">Home 2</a>
                            </li>
                            <li>
                                <a href="#">Home 3</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">About</a>
                        <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false"
                           className="dropdown-toggle">Pages</a>
                        <ul className="collapse list-unstyled" id="pageSubmenu">
                            <li>
                                <a href="#">Page 1</a>
                            </li>
                            <li>
                                <a href="#">Page 2</a>
                            </li>
                            <li>
                                <a href="#">Page 3</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Portfolio</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>

                <ul className="list-unstyled CTAs">
                    <li>
                        <a href="https://bootstrapious.com/tutorial/files/sidebar.zip" className="download">Download
                            source</a>
                    </li>
                    <li>
                        <a href="https://bootstrapious.com/p/bootstrap-sidebar" className="article">Back to article</a>
                    </li>
                </ul>
            </nav>
        );
    }

    renderNavbar(){
        return (
            <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom" id="navbar-top">
                <button className="btn btn-danger" id="menu-toggle">Mostrar Menú</button>
            </nav>
        );
    }

    renderPageContent(){
        return (
            <div id="page-content-wrapper">

                {this.renderNavbar()}

                <div className="container">
                    <div className="row marco mt-5">
                        <div className="col-12 mt-3 display-4 title">
                            <strong>Home</strong>
                        </div>
                        <div className="col-12 mt-5 menu">
                            <div className="row">
                                <div className="col-4">
                                    <strong>Administrador de Usuarios</strong>
                                </div>
                                <div className="col-8">
                                    <strong>Operaciones</strong>
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="offset-4 col-8">
                                    Operaciones | Movimientos Y Consultas
                                </div>
                            </div>

                            <div className="row mt-5">
                                <div className="col-4">
                                    <strong>Estados Financieros</strong>
                                </div>
                                <div className="col-8">
                                    <strong>Existencias</strong>
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="offset-4 col-8 mb-5">
                                    Stock de Existencias | Movimiento por Ventas | Movimiento Interno | Importar Existencias | Actualizar Existencias
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    render() {
        return (
            <React.Fragment>
                <div className="d-flex" id="wrapper">

                    {this.renderSide()}

                    {this.renderPageContent()}

                </div>
            </React.Fragment>
        );
    }
}

export default  Presentacion;
const sql = require('../config/connection');
const bcrypt = require('bcryptjs');
const momentTimezone = require('moment-timezone');

// ESTE MODELO MANEJA LOS DATOS DE INICIO DE SESIÓN Y LOS DATOS PERSONALES DE LOS USUARIOS, TALES DATOS NO SON TAN ESENCIALES.
class Usuario{
    constructor(usuario = null){
        if (usuario !== null){
            // DATOS DE USUARIO PARA INCIAR SESIÓN Y PRIMER REGISTRO
            this.nombreUM = usuario.nombreUM;
            this.claveHashUM = "";
                if (usuario.rucUM !== undefined){
                this.rucUM = usuario.rucUM;
            }
            if (usuario.claveUM !== undefined){
                this.claveUM = usuario.claveUM;
            }
            if (usuario.creadoPorUM !== undefined){
                this.creadoPorUM = usuario.creadoPorUM;
            }
            if (usuario.tipoPerfilUM !== undefined){
                this.tipoPerfilUM = usuario.tipoPerfilUM;
            }
            if (usuario.habilitadoUM !== undefined){
                this.habilitadoUM = usuario.habilitadoUM;
            }
            if (usuario.idNegocioAsignadoUM !== undefined){
                this.idNegocioAsignadoUM = usuario.idNegocioAsignadoUM;
            }
            // DATOS DE USUARIOS EN OTRA TABLA
            if (usuario.numDocumentoUM !== undefined){
                this.numDocumentoUM = usuario.numDocumentoUM;
            }
            if (usuario.tipoDocumentoUM !== undefined){
                this.tipoDocumentoUM = usuario.tipoDocumentoUM;
            }
            if (usuario.nombresUM !== undefined){
                this.nombresUM = usuario.nombresUM;
            }
            if (usuario.apellidosUM !== undefined){
                this.apellidosUM = usuario.apellidosUM;
            }
            if (usuario.telefonosUM !== undefined){
                this.telefonosUM = usuario.telefonosUM;
            }
            if (usuario.direccionUM !== undefined){
                this.direccionUM = usuario.direccionUM;
            }
            if (usuario.correosUM !== undefined){
                this.correosUM = usuario.correosUM;
            }
            if (usuario.ciudad !== undefined){
                this.ciudad = usuario.ciudad;
            }
            if (usuario.departamento !== undefined){
                this.departamento = usuario.departamento;
            }
            if (usuario.provincia !== undefined){
                this.provincia = usuario.provincia;
            }
        }
    }

    // FUNCIÓN PARA REGISTRAR UN USUARIO NUEVO
    // {nombreUsuario: "", claveUsuario: "", creadoPor: "", tipoPerfil: ""}
    static registrarUsuario(nuevoUsuario, result){
        let fechaSistema = momentTimezone(new Date()).tz('america/Lima'); // libreria para convertir zona horaria - para cuando este en servidor en la nube.
        fechaSistema = fechaSistema.format("YYYY-MM-DD");
        sql.query(
            "INSERT INTO usuarios(nombreUsuario,claveUsuario,token,fechaCreacion,creadoPor,tipoPerfil,habilitado,numDocumento,nombres,apellidos) VALUES(?,?,?,?,?,?,?,?,?,?)",
            [nuevoUsuario.nombreUsuario, nuevoUsuario.claveHash,'-',fechaSistema,nuevoUsuario.creadoPor, nuevoUsuario.tipoPerfil,1,nuevoUsuario.numDocumento,nuevoUsuario.nombres,nuevoUsuario.apellidos],
            (err, res) => {
                if (err){
                    result(err, null);
                }else{
                    result(null, res);
                }
            }
        );
    }

    static inicioSesion(usuario, result){
        sql.query(
            'SELECT usr.idUsuario,usr.nombreUsuario,usr.claveUsuario,usr.fechaCreacion,usr.creadoPor,usr.tipoPerfil,usr.habilitado, permisosasignados.* FROM usuarios AS usr INNER JOIN permisosasignados ON usr.idUsuario = permisosasignados.idUsuarioAsignado WHERE usr.nombreUsuario=?;',
            [usuario.nombreUsuario],
            async (err, res) => {
                if (err){
                    result(err, null);
                }else{
                    if (res.length > 0){
                        if (Usuario.compareHash(res[0].claveUsuario, usuario.claveUsuario)){
                            res[0].permisos = [];
                            for (let i = 0; i < res.length; i++){
                                res[0].permisos.push(res[i].idPermisoAsignado);
                                console.log("Asignando:", res[i].idPermisoAsignado);
                            }
                            delete res[0].idUsuarioAsignado;
                            delete res[0].idPermisoAsignado;
                            delete res[0].claveUsuario;
                            delete res[0].fechaCreacion;
                            result(null, res[0]);
                        }else{
                            result(null, []);
                        }
                    }else{
                        result(null, res);
                    }
                }
            }
        );
    }

    static generarToken(data){
        const JWT = require('jsonwebtoken');

        const dataToken = {
            idUsuario: data.idUsuario,
            nombreUsuario: data.nombreUsuario,
            tipoPerfil: data.tipoPerfil,
            timeStamp: new Date(),
            permisos: data.permisos,
            habilitado: data.habilitado,
            creadoPor: data.creadoPor,
        }; // -----------------

        let JWT_PASS_SECRET = "";

        if (process.env.JWT_PASS_SERVER) {
            JWT_PASS_SECRET = process.env.JWT_PASS_SERVER;
        } else {
            JWT_PASS_SECRET = "%%-M1P0d3r0s4Cl4v3-%%";
        }

        let dieTime = {
            expiresIn: '24h'
        };

        return JWT.sign(
            dataToken,
            JWT_PASS_SECRET,
            dieTime
        );
    };

    static recuperarPermisos(usuario){
        sql.query(
            'SELECT * FROM permisosasignados WHERE idUsuarioAsignado=?',
            [usuario.idUsuario],
            (err, res) =>{
                if (err){
                    return [];
                }else{
                    console.log("EN FN RecuperarPermisos", res);
                    usuario.permisos = res;
                    return res;
                }
            }
        );
    }

    static guardarTokenDb(usuario, token){
        sql.query(
            'UPDATE usuarios SET token=? WHERE idUsuario=?',
            [token, usuario.idUsuario],
            (err, res) => {
                if (err){
                    return false;
                }
                return true;
            }
        );
    }

    static toHash(clave){
        console.log("clave:", clave);
        const salt = bcrypt.genSaltSync(10);
        return bcrypt.hashSync(clave, salt);
    }

    static compareHash(hashClave, clavePlano){
        return bcrypt.compareSync(clavePlano, hashClave);
    }

    static obtenerUsuarios(idUsuario, result){
        let sql_command = '';
        if (idUsuario === 0){
            sql_command = 'SELECT usuarios.*,perfiles.nombrePerfil FROM usuarios INNER JOIN perfiles ON usuarios.tipoPerfil=perfiles.idPerfil';
        }else{
            sql_command = 'SELECT usuarios.*,perfiles.nombrePerfil FROM usuarios INNER JOIN perfiles ON usuarios.tipoPerfil=perfiles.idPerfil WHERE idUsuario=?';
        }
        sql.query(
            sql_command,
            [idUsuario],
            (err, res) => {
                if (err){
                    result(err, null);
                }else{
                    result(null, res);
                }
            });
    }

    static dehabilitarUsuario(id_Usuario, result){
        sql.query(
            'UPDATE usuarios SET habilitado=\'0\' WHERE idUsuario=?',
            [id_Usuario],
            (err, res) => {
                if (err){
                    console.log("Error en consulta a DB:", err);
                    result(err, null);
                }else{
                    console.log("Sin errores al consultar a la base de datso:", res);
                    result(null, res);
                }
            }
        );
    }

    static habilitarUsuario(idUsuario, result){
        sql.query(
            'UDATE usuarios SET habilitado=1 WHERE idUsuario=?',
            [idUsuario],
            (err, res) => {
                if (err){
                    result(err, null);
                }else{
                    result(null, res);
                }
            }
        );
    }


}

module.exports = Usuario;
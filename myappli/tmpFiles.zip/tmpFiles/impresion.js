<React.Fragment>
    <div className="container-fluid bg-white">
        <div className="body-atajos" id="comprobante">
            <Ticket
                ancho={300}
                conBordes={false}
                nombreComercial={"Mi negocio"}
                razonSocial={"NEOGICOS S.A.C."}
                ruc={20423786296}
                direccion={"Lircay 104 - San Martín - Socabaya"}
                telefono={"949044802"} rubros={"De todo"}
                imagenEmpresa={"http://shmector.com/_ph/13/510962645.png"}
                nombres={"Armando"}
                apellidoP={"Hinojosa"}
                apellidoM={"Ccama"}

                tamLetraCabecera={"11px"}
                tamLetraTipo={"11px"}
                tamLetraCliente={"11px"}
                tamLetraDetalles={"11px"}
                tamLetraTotal={"11px"}

                tipoComprobante={"Factura Electrónica"}
                serie={"E001"} numero={1025558874}

                // Cliente
                rucCliente={"1025369825"}
                cliente={"Diego ramos"}
                direccionCliente={"Calle 123 - Urbanizacion - Distrito"}
                telefonoCliente={"342877342"}
                correoCliente={"correo@correo.com"}

                // detalles de comprobante
                cabezarasDescripcion={["Cant.", "Descripcion", "Precio", "SubTotal"]}
                items={[
                    {cant: 23, descripcion: "mesas", precio: "12.55", subtotal: "651.54"},
                    {cant: 52, descripcion: "sillas", precio: "10.55", subtotal: "84841.54"},
                    {cant: 2, descripcion: "bancas", precio: "6.5", subtotal: "51.54"},
                ]}

                // TOTALES
                totalValorCompra={4564}
                sumatoriaTributos={6524}
                totalDescuento={345}
                totalPrecioVenta={34}
                sumatoriaOtrosCargos={435}
            />
        </div>
    </div>
    <br/><br/><br/>
    <ButtonPrinter elemento={'comprobante'} classButton={'btn-danger'}/>
</React.Fragment>